import React from 'react'
import './Home.css'
import Figma from '../assets/figma-logo.png'
import Black from '../assets/black-logo.png'
import Diamont from '../assets/diamond-logo.png'
import MyPhoto from '../assets/my-photo.jpg'



function Home() {
  return (
    <div>
      <div className='body'>
          <div className='body-left' >
              <div className='Hi-div' >
                <h1 className='hi'>👋 Hi, I’m AKSHAY</h1>
              </div>
              <div className='about'>
                <p className='about-para'>
                I’m a <b>Web Developer</b> with a passion for participate in every stage of digital product, from discovery to delivery. Helping to focus the business goals on users.
                </p>
              </div>
              <div className='me' >
                <div className='expert'>
                <p className='expert-p' id='e1' >I’m looking for new opportunities</p>
                <p className='expert-p' id='e2' >NOW
                <spam className="expert-spam"> IM STUDING AT DR.NGP IT</spam></p>
               
                </div>
                <div className='contact'>
                    <p className='contact-p' id='c1'>.MINE.</p>
                    <p className='contact-p' id='c2'>akshayananth01@gmail.com</p>
                </div>

              </div>
              <div className='project-click' >
                <div className='project-logo' >
                    <p className='para-logo' >👇</p>
                </div>
                <div className='project-click' >
                    <p className='para-click'>
                    Check some projects
                    </p>
                </div>
              </div>

          </div>
          <div className='body-right' >
            <div className='UI-kit' >
                <p className='UI-para'>🎨  UI Kit</p>
            </div>
            
           

            <div className='icons' >
            <p className='icons-para'>🔔  Skills</p>
            </div>

          

            <div className='fonts'>
            <p className='fonts-para'>🔤 creator </p>
          </div>

            

           

            

            <div className='profile'>
                <div className='details'>
                <div className='profile-photo' >
                        <img className='my-photo' src={MyPhoto} alt="my-photo-logo" />
                </div>              
              <div className='uxui' >
                <p className='uxui-para'>
                    MINE
                </p>
              </div>

            <div className='name' >
                <p className='name-para' >..AKSHAY..</p>
            </div>

            <div className='work' >
                <p >Student</p>
            </div></div>
            </div>
            <div className='diamont'>
              <img className='diamont-logo' src='\yt.png' alt="diamont-logo" />
            </div>
            <div className='user-research'>
            <p className='user-research-para'>🔍  Explorer</p>
            </div>
            <div className='black' >
                <img className='black-logo' src='\images.png' alt="black-logo" />
            </div>
            <div className='flow-charts'>
            <p className='flow-charts-para'>🔀  vlogger</p>
            </div>
          </div>
        </div>
        </div>

  )
}

export default Home
