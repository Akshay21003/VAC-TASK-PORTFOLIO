import './App.css'
import Nav from './Nav'
import Home from './pages/Home'

function App() {
 
  return (
    <>
    <div>
      <Nav/>
 
    </div>
        
    </>
  )
}

export default App
